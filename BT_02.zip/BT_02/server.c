#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>

#define PORT 8080
#define MAX_BUF_SIZE 1024

int main(int argc, char const *argv[]) {
    int server_fd, new_socket, valread;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);
    char buffer[MAX_BUF_SIZE] = {0};
    char search_str[] = "0123456789";
    int search_str_len = strlen(search_str);
    int count = 0;
   
    // Tạo file descriptor cho socket
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }
      
    // Thiết lập các option cho socket
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
        perror("setsockopt failed");
        exit(EXIT_FAILURE);
    }
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons( PORT );
      
    // Liên kết socket với địa chỉ và port được chỉ định
    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address))<0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    
    // Lắng nghe các kết nối đến trên socket
    if (listen(server_fd, 3) < 0) {
        perror("listen failed");
        exit(EXIT_FAILURE);
    }

    // Chấp nhận các kết nối đến và tạo socket mới cho mỗi kết nối
    if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen))<0) {
        perror("accept failed");
        exit(EXIT_FAILURE);
    }
    
    while (1) {
        // Nhận dữ liệu từ client
        valread = read(new_socket, buffer, MAX_BUF_SIZE);
        
        // Kiểm tra trường hợp xâu "0123456789" nằm giữa 2 lần truyền
        if (count > 0) {
            if (buffer[0] != '0') {
                count = 0;
            }
        }
        
        // Tìm số lần xuất hiện của xâu "0123456789"
        char *pos = buffer;
        while ((pos = strstr(pos, search_str)) != NULL) {
            count++;
            pos += search_str_len;
        }

        
        // In số lần xuất hiện của xâu "0123456789"
        printf("Number of occurrences of '%s': %d\n", search_str, count);


        
        // // Reset buffer và đếm số lần xuất hiện của xâu "0123456789" sau mỗi lần truyền
        // memset(buffer, 0, MAX_BUF_SIZE);
        // if (count > 0 && buffer[0] == '0') {
        //     count = 1;
        // } else {
        //     count = 0;
        // }


        break;

    }

    return 0;
}
